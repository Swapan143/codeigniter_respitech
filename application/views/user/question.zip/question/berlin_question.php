<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>work</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" type="text/css" href="<?=base_url()?>webroot/user_panel/assets/img/question/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="<?=base_url()?>webroot/user_panel/assets/img/question/css/style.css" />
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>

<body>
  <div class="banner_free_sleep_quiz">
    <div class="free_sleep_banner">
      <div class="banner_img_free_sleep"><img src="<?=base_url()?>webroot/user_panel/assets/img/question/img/banner_sleep.jpg" alt="img" /></div>
    </div>
    <div class="banner_free_sleep_text">
      <div class="free_sleep_logo">
        <img src="https://respitech.co.in/webroot/admin/images/logo.png" alt="" />
      </div>
      <h2 class="fs-1 text-uppercase">
        Did You Know !!
        <br />
      </h2>
      <h4>Nearly 1 billion people worldwide have sleep apnea..</h4>
      <p>
        Why You Should Take This Sleep Assessment: Free Sleep
        <br />
        Assessment to know your Sleep Health
      </p>
      <p>
        <strong>
          <span class="material-symbols-outlined align-middle">
            update
          </span> within 3 to 5 mins
        </strong>
      </p>
      <div>
        <a href="#start" class="cmn_btn2 color_btn">Start Now <span class="material-symbols-outlined align-middle">
            double_arrow
          </span></a>
      </div>
    </div>
  </div>
  <div class="banner_bottom">
    <div class="container">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-sm-8">
          <p class="mb-0 ps-5 pe-5">
            <strong><strong> A good night's sleep</strong> is important for your physical and mental health, as well as
              your quality of life.
              During sleep,
              many important functions take place that help the body repair itself.2 This sleep assessment can help you
              understand
              your sleep behavior and determine if you should consider talking to a doctor about your sleep health
              <br />
              एक अच्छी रात की नींद आपके शारीरिक और मानसिक स्वास्थ्य के साथ-साथ आपके जीवन की गुणवत्ता के लिए महत्वपूर्ण
              है। नींद
              के दौरान, कई महत्वपूर्ण कार्य होते हैं जो शरीर को खुद की मरम्मत में मदद करते हैं।2 यह नींद मूल्यांकन आपको
              अपने नींद के
              व्यवहार को समझने में मदद कर सकता है और यह निर्धारित कर सकता है कि क्या आपको अपने नींद के स्वास्थ्य के बारे
              में डॉक्टर
              से बात करने पर विचार करना चाहिए।
          </p>
        </div>
      </div>
    </div>
  </div>
  <form id="address-add" action="<?=base_url('berlin-questionnaire-submit')?>" class="form-class" method="post" enctype="multipart/form-data">
    <div class="container sleep_form">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-sm-8">
          <div id="start" class="text-center bg-white shadow rounded">
            <div class="p-4">
              <div class="row">
                <div class="col-md-6 mb-2">
                  <label>First Name (प्रथम नाम)*
                  </label>
                  <input type="text" class="form-control" name="first_name" id="first_name"/>
                </div>
                <div class="col-md-6 mb-2">
                  <label>Last Name (कुलनाम)*</label>
                  <input type="text" class="form-control"  name="last_name" id="last_name" />
                </div>

                <div class="col-md-5 mb-2">
                  <div class="row">
                    <div class="col-sm-3">
                      <label>Height (पराकाष्ठा)*</label>
                      <input type="text" class="form-control"  name="height" id="height"/>
                    </div>
                    <div class="col-sm-3">
                      <label>Weight (वजन)*</label>
                      <input type="text" class="form-control"  name="weight" id="weight"/>
                    </div>
                    <div class="col-sm-3">
                      <label>Age (उम्र)*</label>
                      <input type="text" class="form-control"  name="age" id="age"/>
                    </div>
                    <div class="col-sm-3">
                      <label>Gender (लिंग)*</label>
                      <select class="form-control"name="gender" id="gender">
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-7 mb-2">
                  <label>Who are you completing this sleep assessment for? आप इस नींद मूल्यांकन को किसके लिए पूरा कर रहे
                    हैं?</label>
                    <input type="text" class="form-control" name="phone" id="phone"/>
                </div>

                <div class="col-md-4 mb-2">
                  <label>State राज्य</label>
                  <input type="text" class="form-control" name="state" id="state"/>

                </div>

                <div class="col-md-4 mb-2">
                  <label>City शहर</label>
                  <input type="text" class="form-control" name="city" id="city"/>

                </div>

                <div class="col-md-4 mb-2">
                  <label>Phone number फोन संख्या*</label>
                  <input type="text" class="form-control" name="phone" id="phone"/>
                </div>
              </div>
            </div>

            <div class="text-left pl-3 ps-3 pe-3 pb-3">
              <h6>
                <strong> Purposefully Designed to help and identify individuals/ Non-patients at high risk for sleep
                  apnea, the
                  short</strong>
                survey (11
                questions) focuses on three categories of apnea signs and symptoms:
                <br />
                स्लीप एपनिया के लिए उच्च जोखिम वाले व्यक्तियों / गैर-रोगियों की सहायता और पहचान करने के लिए उद्देश्यपूर्ण
                रूप
                से डिज़ाइन किया गया, लघु सर्वेक्षण (11 प्रश्न) एपनिया संकेतों और लक्षणों की तीन श्रेणियों पर केंद्रित है:
              </h6>
              <ul class="ul_list">
                <li>i. Snoring (खर्राटे),</li>
                <li> ii. Daytime Sleepiness, and (द्वितीय। दिन में तंद्रा, और)</li>
                <li>iii. Obesity / High Blood Pressure. (तृतीय. मोटापा/उच्च रक्तचाप।)</li>
              </ul>
              <br />
              <p>he instrument may be indicated for use in both research, and as a screening tool for clinicians hoping to
                quickly
                establish apnea risk factors in their patients. Population for Testing Validated in patients 18 years old
                and over.
                <br />
                उपकरण को अनुसंधान दोनों में उपयोग के लिए संकेत दिया जा सकता है, और चिकित्सकों के लिए एक स्क्रीनिंग उपकरण
                के रूप में अपने
                रोगियों में एपनिया जोखिम कारकों को जल्दी से स्थापित करने की उम्मीद है। परीक्षण के लिए जनसंख्या 18 वर्ष और
                उससे अधिक उम्र
                के रोगियों में मान्य है।
              </p>
              <p class="mb-0">
                Administration Questions are self-reported in a paper-and-pencil format:
                <br />
                प्रशासन प्रश्न एक कागज और पेंसिल प्रारूप में स्व-रिपोर्ट किए जाते हैं:
              </p>
              <span class="fw-normal">
                Administration should require about 5–10 min, though possibly longer as blood pressure may need to be
                taken and recent
                weight and height measurements are necessary for the calculation of body mass index.
                <br />
                प्रशासन के बारे में 5-10 मिनट की आवश्यकता होनी चाहिए, हालांकि संभवतः लंबे समय तक रक्तचाप लिया जा सकता है
                और हाल
                ही में वजन और ऊंचाई माप शरीर द्रव्यमान सूचकांक की गणना के लिए आवश्यक हैं.
              </span>
              <br />
              <p class="mb-0 mt-3">
                Reliability and Validity: (विश्वसनीयता और वैधता)
              </p>
              <span class="fw-normal">
                A number of studies have examined the psychometric properties of the instrument, and findings suggest that
                the kind of
                patient population being examined has some bearing on the sensitivity and efficacy of the measure.
                <br />
                कई अध्ययनों ने उपकरण के साइकोमेट्रिक गुणों की जांच की है, और निष्कर्ष बताते हैं कि जिस तरह की रोगी आबादी
                की जांच की
                जा रही है, उसका माप की संवेदनशीलता और प्रभावकारिता पर कुछ असर पड़ता है।
              </span>
              <br />
              <p class="mt-3 mb-0">Study Findings: (अध्ययन के निष्कर्ष)</p>
              <ul class="ul_list">
                <li>i. found the tool to be moderately sensitive in a surgical patient population, a second study
                  examining patients at a
                  sleep clinic,
                  <br />
                  एक शल्य चिकित्सा रोगी आबादी में मामूली संवेदनशील होने के लिए उपकरण पाया, एक नींद क्लिनिक में रोगियों की
                  जांच करने वाला एक दूसरा अध्ययन,
                </li>
                <li> ii. Discovered a sensitivity of only 62%, making it unlikely to benefit clinicians during
                  diagnosis. In almost all of
                  the literature, the tool appears to be more valuable when apnea is moderate or severe.
                  <br />
                  केवल 62% की संवेदनशीलता की खोज की, जिससे निदान के दौरान चिकित्सकों को लाभ होने की संभावना नहीं है। लगभग
                  सभी साहित्य में,
                  एपनिया मध्यम या गंभीर होने पर उपकरण अधिक मूल्यवान प्रतीत होता है।
                </li>
                <li>iii. As the scoring process tends to be rather complex in comparison to other apnea scales, the
                  instrument is often
                  recommended for use by sleep specialists or individuals with similarly relevant training. The survey
                  evaluates “yes or
                  no” responses and multiple-choice selections, and includes space for calculating Body Mass Index (BMI)
                  based on
                  respondent measurements.
                  <br />
                  चूंकि स्कोरिंग प्रक्रिया अन्य एपनिया तराजू की तुलना में जटिल हो जाती है, इसलिए उपकरण को अक्सर नींद
                  विशेषज्ञों या समान प्रासंगिक प्रशिक्षण वाले व्यक्तियों द्वारा उपयोग के लिए अनुशंसित किया जाता है।
                  सर्वेक्षण "हां या
                  नहीं" प्रतिक्रियाओं और बहुविकल्पीय चयनों का मूल्यांकन करता है, और इसमें प्रतिवादी माप के आधार पर बॉडी
                  मास
                  इंडेक्स (बीएमआई) की गणना के लिए स्थान शामिल है।
                </li>
              </ul>

              <p class="mt-3 mb-0">Study Findings:</p>
              <span class="d-block fw-normal">
                Points are given to responses that indicate more acute symptoms. For “yes or no” questions, one point is
                given to an
                answer of “yes.” In the case of multiple-choice questions, the two answers that correspond with the
                highest severity of
                apnea both receive one point. Categories one and two are considered high risk if the individual receives
                two or more
                points. Category three questions (obesity and blood pressure). The respondent is considered high risk when
                blood
                pressure is found to be high or when BMI is greater than 30 kg/m2.

                <br />
                उन प्रतिक्रियाओं को अंक दिए जाते हैं जो अधिक तीव्र लक्षणों का संकेत देते हैं। "हां या नहीं" प्रश्नों के
                लिए, "हां" के
                उत्तर के लिए एक बिंदु दिया जाता है। बहुविकल्पीय प्रश्नों के मामले में, एपनिया की उच्चतम गंभीरता के अनुरूप
                दो उत्तर दोनों
                को एक बिंदु प्राप्त होता है। श्रेणी एक और दो को उच्च जोखिम माना जाता है यदि व्यक्ति को दो या अधिक अंक
                प्राप्त होते हैं।
                श्रेणी तीन प्रश्न (मोटापा और रक्तचाप)। प्रतिवादी को उच्च जोखिम माना जाता है जब रक्तचाप उच्च पाया जाता है
                या जब बीएमआई 30
                किग्रा / एम 2 से अधिक होता है।
              </span>
              <h4 class="mt-3">Questionnaire – Category wise:</h4>

              
              <div class="sleep_form">
                <div class="row d-flex justify-content-center">
                  <div class="col-lg-12">
                    <div class="bg-white shadow rounded p-4">
                      <div class="row">
                        <h6 class="mt-2 mb-0">Please choose the correct response to each question (कृपया प्रत्येक प्रश्न
                          का सही उत्तर चुनें)</h6>
                        <h5>Questionnaire – Category wise: (प्रश्नावली – श्रेणी वार):</h5>
                        <h5 class="mb-0">Category (कैटेगरी )1</h5>
                        <div class="col-md-4 mt-2">
                          <p class="mb-0">1. Do you store? (क्या आप खर्राटे लेते हैं)?</p>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Yes(हाँ)" id="defaultCheck1" name="do_you_store[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Yes(हाँ)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="B. No(नहीं)" id="defaultCheck2" name="do_you_store[]">
                              <label class="form-check-label" for="defaultCheck2">
                                B. No(नहीं)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. Don't Know (पता नहीं)" id="defaultCheck2" name="do_you_store[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. Don't Know (पता नहीं)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4 mt-2">
                          <small class="text-info"><strong>If you Snore:</strong></small>
                          <p class="mb-0">2. Your snoring is: (आपके खर्राटे हैं:)</p>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Slightly louder than breathing (सांस लेने से थोड़ा ज़्यादा तेज़)" id="defaultCheck1" name="your_strong[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Slightly louder than breathing (सांस लेने से थोड़ा ज़्यादा तेज़)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="B. As load as talking (बात करने जितना जोर से)" id="defaultCheck2" name="your_strong[]">
                              <label class="form-check-label" for="defaultCheck2">
                                B. As load as talking (बात करने जितना जोर से)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. Loider than talking (बात करने से भी ज्यादा जोर से)" id="defaultCheck2" name="your_strong[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. Loider than talking (बात करने से भी ज्यादा जोर से)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="d. Very loud -can be head in asjacent room (बहुत तेज़ - बगल के कमरे में भी सुना जा सकता
                                है)" id="defaultCheck2" name="your_strong[]">
                              <label class="form-check-label" for="defaultCheck2">
                                d. Very loud -can be head in asjacent room (बहुत तेज़ - बगल के कमरे में भी सुना जा सकता
                                है)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4 mt-2">
                          <h6 class="mb-0">3. How often do you snore (आप कितनी बार खर्राटे लेते हैं)?</h6>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Nearly every day (लगभग हर दिन)" id="defaultCheck1" name="how_often_snore[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Nearly every day (लगभग हर दिन)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. 3-4 times a week (सप्ताह में 3-4 बार)" id="defaultCheck2" name="how_often_snore[]">
                              <label class="form-check-label" for="defaultCheck2">
                                b. 3-4 times a week (सप्ताह में 3-4 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. 1-2 times a week (सप्ताह में 1-2 बार)" id="defaultCheck2" name="how_often_snore[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. 1-2 times a week (सप्ताह में 1-2 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="d. 1-2 times a month (महीने में 1-2 बार)" id="defaultCheck2" name="how_often_snore[]">
                              <label class="form-check-label" for="defaultCheck2">
                                d. 1-2 times a month (महीने में 1-2 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)" id="defaultCheck2" name="how_often_snore[]">
                              <label class="form-check-label" for="defaultCheck2">
                                e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6 mt-2">
                          <h6 class="mb-0">4. Has your snoring ever bothered other people? (क्या आपके खर्राटों से कभी अन्य
                            लोगों को परेशानी हुई है?)?</h6>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Yes (हाँ)" id="defaultCheck1" name="has_your_snoring_evar[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Yes (हाँ)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. No (नहीं)" id="defaultCheck2" name="has_your_snoring_evar[]">
                              <label class="form-check-label" for="defaultCheck2">
                                b. No (नहीं)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. Don't Know (पता नहीं)" id="defaultCheck2" name="has_your_snoring_evar[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. Don't Know (पता नहीं)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6 mt-2">
                          <h6 class="mb-0">5. Has anyone noticed that you quit breathing during your sleep? (क्या किसी ने
                            यह देखा है कि आप सोते समय सांस लेना बंद कर देते हैं)?</h6>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Nearly every day (लगभग हर दिन)" id="defaultCheck1" name="has_any_one_noticed[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Nearly every day (लगभग हर दिन)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. 3-4 times a week (सप्ताह में 3-4 बार)" id="defaultCheck2" name="has_any_one_noticed[]">
                              <label class="form-check-label" for="defaultCheck2">
                                b. 3-4 times a week (सप्ताह में 3-4 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. 1-2 times a week (सप्ताह में 1-2 बार)" id="defaultCheck2" name="has_any_one_noticed[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. 1-2 times a week (सप्ताह में 1-2 बार)

                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="d. 1-2 times a month (महीने में 1-2 बार)" id="defaultCheck2" name="has_any_one_noticed[]">
                              <label class="form-check-label" for="defaultCheck2">
                                d. 1-2 times a month (महीने में 1-2 बार)

                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="e. Near or nearly never (कभी नहीं या लगभग कभी नहीं)" id="defaultCheck2" name="has_any_one_noticed[]">
                              <label class="form-check-label" for="defaultCheck2">
                                e. Near or nearly never (कभी नहीं या लगभग कभी नहीं)

                              </label>
                            </div>

                          </div>
                        </div>

                      </div>

                      <div class="row">
                        <div class="col-md-12">
                          <hr />
                        </div>
                      </div>

                      <div class="row">
                        <h5 class="mb-0">Category (कैटेगरी ) 2</h5>
                        <div class="col-md-4 mt-2">
                          <p class="mb-0">6. How often do you feel tired or fatigued after you sleep? (आप सोने के बाद
                            कितनी बार थका हुआ या कमज़ोर महसूस करते हैं)?</p>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Nearly every day (लगभग हर दिन)" id="defaultCheck1" name="how_often_do_you_feel[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Nearly every day (लगभग हर दिन)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. 3-4 times a week (सप्ताह में 3-4 बार)" id="defaultCheck2" name="how_often_do_you_feel[]">
                              <label class="form-check-label" for="defaultCheck2">
                                b. 3-4 times a week (सप्ताह में 3-4 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. 1-2 times a week (सप्ताह में 1-2 बार)" id="defaultCheck2" name="how_often_do_you_feel[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. 1-2 times a week (सप्ताह में 1-2 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="d. 1-2 times a month (महीने में 1-2 बार)" id="defaultCheck2" name="how_often_do_you_feel[]">
                              <label class="form-check-label" for="defaultCheck2">
                                d. 1-2 times a month (महीने में 1-2 बार)
                              </label>
                            </div>

                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)" id="defaultCheck2" name="how_often_do_you_feel[]">
                              <label class="form-check-label" for="defaultCheck2">
                                e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4 mt-2">
                          <p class="mb-0">7. During your waking time, do you feel tired, fatigued or not up to par? (क्या
                            आप जागते समय थका हुआ, कमज़ोर या अस्वस्थ महसूस करते हैं)?</p>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Nearly every day (लगभग हर दिन)" id="defaultCheck1" name="during_your_waking_time[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Nearly every day (लगभग हर दिन)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. 3-4 times a week (सप्ताह में 3-4 बार)" id="defaultCheck2" name="during_your_waking_time[]">
                              <label class="form-check-label" for="defaultCheck2">
                                b. 3-4 times a week (सप्ताह में 3-4 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. 1-2 times a week (सप्ताह में 1-2 बार)" id="defaultCheck2" name="during_your_waking_time[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. 1-2 times a week (सप्ताह में 1-2 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="d. 1-2 times a month (महीने में 1-2 बार)" id="defaultCheck2" name="during_your_waking_time[]">
                              <label class="form-check-label" for="defaultCheck2">
                                d. 1-2 times a month (महीने में 1-2 बार)
                              </label>
                            </div>

                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)" id="defaultCheck2" name="during_your_waking_time[]">
                              <label class="form-check-label" for="defaultCheck2">
                                e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)
                              </label>
                            </div>

                          </div>
                        </div>
                        <div class="col-md-4 mt-2">
                          <h6 class="mb-0">8. Have you ever nodded off or fallen asleep while driving a vehicle? (क्या आप
                            कभी वाहन चलाते समय झपकी लेते हैं या सो जाते हैं)?</h6>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Yes (हाँ)" id="defaultCheck1">
                              <label class="form-check-label" for="defaultCheck1" name="hao_you_evar_nodded_off[]">
                                a. Yes (हाँ)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. No (नहीं)" id="defaultCheck2">
                              <label class="form-check-label" for="defaultCheck2" name="hao_you_evar_nodded_off[]">
                                b. No (नहीं)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4 mt-2">
                          <small class="text-info">If Yes:</small>
                          <h6 class="mb-0">9. How offen does this occur? (ऐसा कितनी बार होता है)?</h6>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="a. Nearly every day (लगभग हर दिन)" id="defaultCheck1" name="how_offen_does_this_occur[]">
                              <label class="form-check-label" for="defaultCheck1">
                                a. Nearly every day (लगभग हर दिन)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="b. 3-4 times a week (सप्ताह में 3-4 बार)" id="defaultCheck2" name="how_offen_does_this_occur[]">
                              <label class="form-check-label" for="defaultCheck2">
                                b. 3-4 times a week (सप्ताह में 3-4 बार)

                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="c. 1-2 times a week (सप्ताह में 1-2 बार)" id="defaultCheck2" name="how_offen_does_this_occur[]">
                              <label class="form-check-label" for="defaultCheck2">
                                c. 1-2 times a week (सप्ताह में 1-2 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value=" d. 1-2 times a month (महीने में 1-2 बार)" id="defaultCheck2" name="how_offen_does_this_occur[]">
                              <label class="form-check-label" for="defaultCheck2">
                                d. 1-2 times a month (महीने में 1-2 बार)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)" id="defaultCheck2" name="how_offen_does_this_occur[]">
                              <label class="form-check-label" for="defaultCheck2">
                                e. Never or nearly never (कभी नहीं या लगभग कभी नहीं)
                              </label>
                            </div>
                          </div>
                        </div>

                      </div>


                      <div class="row">
                        <div class="col-md-12">
                          <hr />
                        </div>
                      </div>

                      <div class="row">
                        <h5 class="mb-0">Category (कैटेगरी ) 3</h5>
                        <div class="col-md-3 mt-2">
                          <p class="mb-0">10. Do you have hign blood pressure? (क्या आपको उच्च रक्तचाप है)?</p>
                          <div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="Yes (हाँ)" id="defaultCheck1" name="do_you_have_hign_blood_pressure[]">
                              <label class="form-check-label" for="defaultCheck1">
                                Yes (हाँ)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="No (नहीं)" id="defaultCheck2" name="do_you_have_hign_blood_pressure[]">
                              <label class="form-check-label" for="defaultCheck2">
                                No (नहीं)
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="Don't know (पता नहीं)" id="defaultCheck2" name="do_you_have_hign_blood_pressure[]">
                              <label class="form-check-label" for="defaultCheck2">
                                Don't know (पता नहीं)
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-9 mt-2">
                          <div>
                            <table width="100%">
                              <tr>
                                <td width="50%">Please mark "X" as appropriate (कृपया उपयुक्त के रूप में चिह्नित करें)
                                </td>
                                <td class="text-center">Almost Daily (लगभग दैनिक)</td>
                                <td class="text-center">Often (अक्सर)</td>
                                <td class="text-center">Rarely (कभी-कभार)</td>
                                <td class="text-center">Not at all (बिल्कुल नहीं)</td>
                              </tr>
                              <tr>
                                <td width="50%">Do you typically awaken with a dry mouth? (क्या आप आमतौर पर सूखे मुंह के
                                  साथ जागते हैं)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_dry_month[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_dry_month[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_dry_month[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_dry_month[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Do you typically awaken with a store throa? (क्या आप अक्सर गले में दर्द के
                                  साथ जागते हैं)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_throa[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_throa[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_throa[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_throa[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Do you drool on your pillow during the night? (क्या आप रात में तकिये पर
                                  लार टपकाते हैं)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_during_the_night[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_during_the_night[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_during_the_night[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_during_the_night[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Men: Do you have problem eith penile erection (i.e. impotence)? ( पुरुष:
                                  क्या आपको लिंग में तनाव (यानी नपुंसकता) की समस्या है)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_penile_erection[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_penile_erection[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_penile_erection[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_penile_erection[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Do you experience frequent heartburn or reflux during the night? (क्या
                                  आपको रात में अक्सर सीने में जलन या भाटा महसूस होता है)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_reflux[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_reflux[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_reflux[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_reflux[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Do you wake up with headaches in the morning? (क्या आप सुबह उठते समय सिर
                                  दर्द से परेशान रहते हैं)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_the_morning[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_the_morning[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_the_morning[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_the_morning[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Did you ever have a fractured jaw, broken nose or oral problem? (क्या आपको
                                  कभी जबड़े में फ्रैक्चर, नाक में फ्रैक्चर या मुंह की समस्या हुई है)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_broken_nose[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_broken_nose[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_broken_nose[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_broken_nose[]">
                                </td>
                              </tr>
                              <tr>
                                <td width="50%">Have you ever done heavy exercise or manual labour? (क्या आपने कभी भारी
                                  व्यायाम या शारीरिक श्रम किया है)?</td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Almost Daily (लगभग दैनिक)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_manual_labour[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Often (अक्सर)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_manual_labour[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Rarely (कभी-कभार)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_manual_labour[]">
                                </td>
                                <td class="text-center"><input class="form-check-input" type="checkbox" value="Not at all (बिल्कुल नहीं)"
                                    id="defaultCheck2" name="do_you_typically_awaken_store_manual_labour[]">
                                </td>
                              </tr>
                            </table>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <h5 class="text-info mt-5">Representative Studies Using Scale</h5>
                        <hr />
                        <div class="col-md-6">
                          <h4>Representative Studies Using Scale</h4>
                          <strong> 1.</strong> Chung, F., Yegneswaran, B, Liao, P, Chung, S. A.,
                          Vairavanathan, S., Islam, S., Khajehdehi, A.,
                          Shapiro, C. (2008). Validation of the Berlin questionnaire and American Society of
                          Anesthesiologists
                          checklist as screening tools for obstructive sleep
                          apnea in surgical patients. Anesthesiology, 108 (5),
                          822–830.
                          <br />
                          <strong>2.</strong> Ahmadi, N., Chung, S. A., Gibbs, A., & Shapiro, C.
                          (2008).The Berlin questionnaire for sleep apnea in a
                          sleep clinic population: relationship to polysomnographic measurement of respiratory
                          disturbance. Sleep
                          and Breathing, 12 (1), 39–45.
                          <br />
                          <strong> 3.</strong> Netzer NC, Stoohs RA, Netzer CM, Clark K, Strohl
                          KP (1999). Using the Berlin Questionnaire to identify
                          patients at risk for the sleep apnea syndrome. Ann
                          Intern Med , 131(7):485–491.
                        </div>
                        <div class="col-md-6">
                          <h4>Representative Studies Using Scale</h4>
                          Chung, F., Ward, B., Ho, J., Yuan, H., Kayumov, L., &
                          Shapiro, C. (2007). Preoperative identifi cation of sleep
                          apnea risk in elective surgical patients, using the Berlin
                          questionnaire. Journal of Clinical Anesthesia, 19 (2),
                          130–134.
                          <br />
                          Hiestand, D. M., Britz, P., Goldman, M., & Phillips, B.
                          (2006). Prevalence of symptoms of obstructive sleep
                          apnea in the US population: results from the National
                          Sleep Foundation sleep in America 2005 poll. Chest,
                          130 (3), 780–786.
                        </div>

                      </div>
                    </div>
                  </div>
                </div>



              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-12">
        <button class="btn btn-warning btn-primary pull-right m-t-n-xs grediant-btn" type="reset" onclick="tcCancel()"><strong>Cancel</strong></button>
        <button class="btn btn-primary pull-right m-t-n-xs grediant-btn save_submit" type="submit" style="margin-right: 6px;" id="change_password"><strong>Save</strong></button>
    </div>
  </form>

  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
</body>

</html>